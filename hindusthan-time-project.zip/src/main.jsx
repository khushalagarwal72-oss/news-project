import React from "react";
import ReactDOM from "react-dom/client";
import HindusthanTime from "./App.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <HindusthanTime />
  </React.StrictMode>
);
